const NotFound = props => {
    return(
        <div style={{display: 'flex', justifyContent: "center", alignItems: 'center', height: '90vh'}}>
            <p>Page not found!</p>
        </div>
    )
}

export default NotFound;