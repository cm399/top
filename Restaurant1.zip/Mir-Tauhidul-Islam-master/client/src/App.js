import React from 'react';
import MainContexts from './Utils/MainContexts';

const App = () => {
  return <MainContexts />;
};

export default App;
